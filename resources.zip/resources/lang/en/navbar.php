<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Navbar Language Lines
    |--------------------------------------------------------------------------
    */

    'home' => 'Home',
    'article' => 'Knowledge Base',
    'faqs' => 'FAQs',
    'videos' => 'Videos',
    'contact' => 'Contact Us',

];
