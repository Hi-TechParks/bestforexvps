<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Search Language Lines
    |--------------------------------------------------------------------------
    */

    // Header Search Field
    'title' => "How can we help you?",
    'placeholder' => "Ask a question or search by keyword...",

    // Search Result Page
    'result_title' => "Search results for:",
    'no_result' => "No Result Found",

];
