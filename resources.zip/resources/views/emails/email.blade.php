
<!-- Email Template Body -->
<h1>Name: {{ $name }}</h1>
<h4>Email: {{ $email }}</h4>
<h4>Phone: {{ $phone }}</h4>

<p>{{ $msg_body }}</p>
<!-- Email Template Body -->